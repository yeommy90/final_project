package com.example.admin.dao;

public interface AdminDAO {

}
